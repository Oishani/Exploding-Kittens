# How to play EXPLODING KITTENS on your computer

1. Download the zip folder named kittens.zip
2. Unzip kittens.zip
3. On your Terminal, `cd` into the folder that you just unzipped 
4. Run `make build`
5. Enter the command `make play`
6. Enjoy!